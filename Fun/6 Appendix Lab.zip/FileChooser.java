import javax.swing.JFileChooser;
import javax.swing.JFrame;
import java.io.*;
import java.net.*;
  
/**
 * FileChooser makes working with a file chooser easier for students.  It uses 
 * a JFileChooser to let the user pick a file and returns the chosen file name.
 * 
 * @author Barb Ericson ericson@cc.gatech.edu
 */
public class FileChooser {
  /**
   * Gets the full path for the passed file name.
   * 
   * @param fileName  the name of a file
   * @return          the full path for the file
   */
  public static String getMediaPath(String fileName) {
    String path = null;
    String directory = getMediaDirectory();
        
    // gets the full path
    path = directory + fileName;
    return path;
  }
  
  /**
   * Picks an item using the file chooser.
   * 
   * @param fileChooser  the file Chooser to use
   * @return             the path name
   */
  public static String pickPath(JFileChooser fileChooser)
  {
    String path = null;
    
    /* creates a JFrame to be the parent of the file chooser open dialog
     * if you don't do this then you may not see the dialog
     */
    JFrame frame = new JFrame();
    frame.setAlwaysOnTop(true);
    
    // gets the return value from choosing a file
    int returnVal = fileChooser.showOpenDialog(frame);
    
    // if the return value says the user picked a file 
    if (returnVal == JFileChooser.APPROVE_OPTION)
      path = fileChooser.getSelectedFile().getPath();
    return path;
  }
  
  /**
   * Lets the user pick a file and return the full file name as a string.
   * If the user didn't pick a file then the file name will be null.
   * 
   * @return  the full file name of the picked file or null
   */
  public static String pickAFile()
  {
    JFileChooser fileChooser = null;
    
    // starts off the file name as null
    String fileName = null;
    
    // gets the current media directory
    String mediaDir = getMediaDirectory();
    
    /* creates a file for this and checks that the directory exists
     * and if it does, sets the file chooser to use it
     */
    try {
      File file = new File(mediaDir);
      if (file.exists())
        fileChooser = new JFileChooser(file);
    } catch (Exception ex) {
    }
    
    // if no file chooser yet creates one
    if (fileChooser == null)
      fileChooser = new JFileChooser();
    
    // picks the file
    fileName = pickPath(fileChooser);
    
    return fileName;
  }
  
  /**
   * Gets the directory for the media.
   * 
   * @return  the media directory
   */
  public static String getMediaDirectory() 
  {
    String directory = null;
    File dirFile = null;
    
    // try to find the images directory
      try {
        // get the URL for where we loaded this class 
        Class<?> currClass = Class.forName("FileChooser");
        URL classURL = currClass.getResource("FileChooser.class");
        URL fileURL = new URL(classURL,"../images/");
        directory = fileURL.getPath();
        directory = URLDecoder.decode(directory, "UTF-8");
        dirFile = new File(directory);
        if (dirFile.exists()) {
          return directory;
        }
      } catch (Exception ex) {
      }
      
      return directory;
  }
  
}